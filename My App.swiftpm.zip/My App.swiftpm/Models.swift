import Foundation

enum Campus: String, CaseIterable, Identifiable, Hashable {
    case rouse
    case ut

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .rouse: return "Rouse HS"
        case .ut:    return "UT Austin"
        }
    }
}

enum NodeType: String, Codable {
    case classroom = "CLASSROOM"
    case junction  = "JUNCTION"
    case stairs    = "STAIRS"
    case elevator  = "ELEVATOR"
    case entrance  = "ENTRANCE"
    case building  = "BUILDING"
    case amenity   = "AMENITY"

    var isPickable: Bool {
        switch self {
        case .junction, .stairs, .elevator: return false
        default: return true
        }
    }

    var systemImage: String {
        switch self {
        case .classroom: return "graduationcap"
        case .building:  return "building.2"
        case .entrance:  return "door.left.hand.open"
        case .amenity:   return "mappin.circle"
        case .stairs:    return "stairs"
        case .elevator:  return "arrow.up.and.down"
        case .junction:  return "point.bottomleft.filled.forward.to.point.topright.scurvepath"
        }
    }
}

enum EdgeKind: String, Codable {
    case hallway     = "HALLWAY"
    case stairsUp    = "STAIRS_UP"
    case stairsDown  = "STAIRS_DOWN"
    case elevator    = "ELEVATOR"
    case outdoor     = "OUTDOOR"
    case doorway     = "DOORWAY"

    var reversed: EdgeKind {
        switch self {
        case .stairsUp:   return .stairsDown
        case .stairsDown: return .stairsUp
        default:          return self
        }
    }
}

struct Node: Identifiable, Hashable {
    let id: String
    let type: NodeType
    let floor: Int
    let building: String
    let lat: Double
    let lon: Double
    let name: String

    var hasCoordinates: Bool { lat != 0 || lon != 0 }

    func subtitle(in campus: Campus) -> String {
        switch campus {
        case .rouse: return "Floor \(floor) · \(building)"
        case .ut:    return building
        }
    }
}

struct AdjacentEdge: Hashable {
    let to: String
    let seconds: Int
    let kind: EdgeKind
}

struct TraversedEdge: Hashable {
    let from: String
    let to: String
    let kind: EdgeKind
    let seconds: Int
}

struct RouteStep: Hashable, Identifiable {
    let id = UUID()
    let instruction: String
    let detail: String?
    let kind: EdgeKind?
}

struct Route: Hashable {
    let path: [Node]
    let edges: [TraversedEdge]
    let totalSeconds: Int
    let steps: [RouteStep]

    var etaLabel: String {
        if totalSeconds < 60 { return "\(totalSeconds) sec" }
        let mins = totalSeconds / 60
        let secs = totalSeconds % 60
        return secs == 0 ? "\(mins) min" : "\(mins) min \(secs) sec"
    }

    var floorsTraversed: Int {
        Set(path.map(\.floor)).count
    }

    var hasMappableCoordinates: Bool {
        path.contains(where: { $0.hasCoordinates })
    }
}

import Foundation

protocol NavigationService: Sendable {
    func locations(campus: Campus) async throws -> [Node]
    func route(campus: Campus, from: String, to: String) async throws -> Route
}

enum NavigationError: LocalizedError {
    case unknownLocation(String)
    case noPath
    case backendUnreachable
    case backendStatus(Int)

    var errorDescription: String? {
        switch self {
        case .unknownLocation(let id):
            return "Location \"\(id)\" was not found on this campus."
        case .noPath:
            return "No path could be found between those two locations."
        case .backendUnreachable:
            return "Couldn't reach the Java backend. Start it with ./run.sh and run the app in the iOS Simulator."
        case .backendStatus(let code):
            return "The Java backend returned an error (HTTP \(code))."
        }
    }
}

struct LocalNavigationService: NavigationService {

    func locations(campus: Campus) async throws -> [Node] {
        let graph = GraphData.graph(for: campus)
        return graph.nodes.values
            .filter { $0.type.isPickable }
            .sorted { $0.name < $1.name }
    }

    func route(campus: Campus, from: String, to: String) async throws -> Route {
        let graph = GraphData.graph(for: campus)
        guard graph.nodes[from] != nil else { throw NavigationError.unknownLocation(from) }
        guard graph.nodes[to]   != nil else { throw NavigationError.unknownLocation(to)   }
        guard let result = graph.shortestPath(from: from, to: to) else {
            throw NavigationError.noPath
        }
        let steps = DirectionsBuilder.build(path: result.path, edges: result.edges)
        return Route(
            path: result.path,
            edges: result.edges,
            totalSeconds: result.totalSeconds,
            steps: steps
        )
    }
}

struct RemoteNavigationService: NavigationService {
    let baseURL: URL

    init(baseURL: URL = URL(string: "http://localhost:8080")!) {
        self.baseURL = baseURL
    }

    func locations(campus: Campus) async throws -> [Node] {
        let url = makeURL(path: "/api/locations", items: [
            URLQueryItem(name: "campus", value: campus.rawValue)
        ])
        let data = try await fetch(url)
        let decoded = try JSONDecoder().decode(LocationsResponse.self, from: data)
        return decoded.locations.map { $0.toNode() }.sorted { $0.name < $1.name }
    }

    func route(campus: Campus, from: String, to: String) async throws -> Route {
        let url = makeURL(path: "/api/route", items: [
            URLQueryItem(name: "campus", value: campus.rawValue),
            URLQueryItem(name: "from", value: from),
            URLQueryItem(name: "to", value: to)
        ])
        let data = try await fetch(url)
        let decoded = try JSONDecoder().decode(RouteResponse.self, from: data)
        let path = decoded.path.map { $0.toNode() }
        let edges = decoded.edges.map { $0.toEdge() }
        let steps = DirectionsBuilder.build(path: path, edges: edges)
        return Route(path: path, edges: edges, totalSeconds: decoded.totalSeconds, steps: steps)
    }

    private func makeURL(path: String, items: [URLQueryItem]) -> URL {
        var comps = URLComponents(url: baseURL.appendingPathComponent(path), resolvingAgainstBaseURL: false)!
        comps.queryItems = items
        return comps.url!
    }

    private func fetch(_ url: URL) async throws -> Data {
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse else {
                throw NavigationError.backendUnreachable
            }
            guard (200...299).contains(http.statusCode) else {
                throw NavigationError.backendStatus(http.statusCode)
            }
            return data
        } catch let error as NavigationError {
            throw error
        } catch {
            throw NavigationError.backendUnreachable
        }
    }
}

private struct NodeDTO: Decodable {
    let id: String
    let name: String
    let floor: Int
    let building: String
    let type: String
    let lat: Double
    let lon: Double

    func toNode() -> Node {
        Node(
            id: id,
            type: NodeType(rawValue: type) ?? .amenity,
            floor: floor,
            building: building,
            lat: lat,
            lon: lon,
            name: name
        )
    }
}

private struct EdgeDTO: Decodable {
    let from: String
    let to: String
    let seconds: Int
    let kind: String

    func toEdge() -> TraversedEdge {
        TraversedEdge(from: from, to: to, kind: EdgeKind(rawValue: kind) ?? .hallway, seconds: seconds)
    }
}

private struct LocationsResponse: Decodable {
    let locations: [NodeDTO]
}

private struct RouteResponse: Decodable {
    let totalSeconds: Int
    let path: [NodeDTO]
    let edges: [EdgeDTO]
}

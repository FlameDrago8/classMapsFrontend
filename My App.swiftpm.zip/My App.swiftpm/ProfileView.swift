import SwiftUI

struct ProfileView: View {
    @Bindable var profile: ProfileStore
    @Bindable var store: NavigationStore
    @Environment(\.dismiss) private var dismiss
    @State private var nameDraft: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Profile") {
                    HStack(spacing: 14) {
                        ZStack {
                            Circle().fill(Color.accentColor.opacity(0.18))
                            Text(profile.initials)
                                .font(.headline)
                                .foregroundStyle(Color.accentColor)
                        }
                        .frame(width: 48, height: 48)

                        TextField("Display name", text: $nameDraft)
                            .textInputAutocapitalization(.words)
                    }
                }

                Section("Routing source") {
                    Picker("Compute routes with", selection: Binding(
                        get: { store.routingSource },
                        set: { value in Task { await store.setRoutingSource(value) } }
                    )) {
                        ForEach(RoutingSource.allCases) { source in
                            Text(source.label).tag(source)
                        }
                    }
                    .pickerStyle(.inline)
                } footer: {
                    if store.routingSource == .javaBackend {
                        Text("Routes are computed by the Java backend on localhost:8080. Run ./run.sh and launch the app in the iOS Simulator.")
                    } else {
                        Text("Routes are computed on-device in Swift. Works anywhere, including Swift Playgrounds.")
                    }
                }

                Section("Saved routes") {
                    if profile.savedRoutes.isEmpty {
                        Text("No saved routes yet. Find a route and tap the bookmark to save it here.")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(profile.savedRoutes) { saved in
                            Button {
                                Task { await loadSaved(saved) }
                            } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("\(saved.fromName) → \(saved.toName)")
                                        .foregroundStyle(.primary)
                                        .lineLimit(1)
                                    Text("\(campusLabel(saved.campus)) · \(saved.etaLabel)")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .onDelete { indexSet in
                            let ids = indexSet.map { profile.savedRoutes[$0].id }
                            Task { for id in ids { await profile.delete(id) } }
                        }
                    }
                }

                Section {
                    LabeledContent("Storage", value: profile.backendName)
                }
            }
            .navigationTitle("You")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        Task { await profile.updateDisplayName(nameDraft) }
                        dismiss()
                    }
                }
            }
            .onAppear { nameDraft = profile.displayName }
            .task { await profile.load() }
        }
    }

    private func campusLabel(_ raw: String) -> String {
        Campus(rawValue: raw)?.displayName ?? raw
    }

    private func loadSaved(_ saved: SavedRoute) async {
        await profile.updateDisplayName(nameDraft)
        let campus = Campus(rawValue: saved.campus) ?? store.campus
        dismiss()
        await store.applySavedRoute(campus: campus, fromId: saved.fromId, toId: saved.toId)
    }
}

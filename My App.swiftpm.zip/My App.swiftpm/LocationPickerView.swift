import SwiftUI

struct LocationPickerView: View {
    enum Kind {
        case from, to
        var title: String { self == .from ? "From" : "To" }
    }

    @Bindable var store: NavigationStore
    let kind: Kind

    @Environment(\.dismiss) private var dismiss
    @State private var query: String = ""

    private var filtered: [Node] {
        guard !query.isEmpty else { return store.locations }
        return store.locations.filter {
            $0.name.localizedCaseInsensitiveContains(query)
        }
    }

    private var sections: [(title: String, nodes: [Node])] {
        let groupKey: (Node) -> String = {
            switch store.campus {
            case .rouse: return "Floor \($0.floor)"
            case .ut:    return $0.building
            }
        }
        let groups = Dictionary(grouping: filtered, by: groupKey)
        return groups
            .sorted { $0.key.localizedStandardCompare($1.key) == .orderedAscending }
            .map { (title: $0.key, nodes: $0.value.sorted { $0.name < $1.name }) }
    }

    var body: some View {
        List {
            if store.locations.isEmpty {
                if store.isLoadingLocations {
                    HStack { ProgressView(); Text("Loading…") }
                } else {
                    Text("No locations available.").foregroundStyle(.secondary)
                }
            } else {
                ForEach(sections, id: \.title) { section in
                    Section(section.title) {
                        ForEach(section.nodes) { node in
                            Button {
                                select(node)
                            } label: {
                                row(for: node)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .searchable(text: $query, prompt: "Search rooms, buildings…")
        .navigationTitle(kind.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Cancel") { dismiss() }
            }
        }
    }

    private func row(for node: Node) -> some View {
        HStack(spacing: 12) {
            Image(systemName: node.type.systemImage)
                .foregroundStyle(.tint)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 2) {
                Text(node.name)
                    .foregroundStyle(.primary)
                Text(node.subtitle(in: store.campus))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            if isCurrentSelection(node) {
                Image(systemName: "checkmark")
                    .foregroundStyle(.tint)
            }
        }
        .contentShape(Rectangle())
    }

    private func isCurrentSelection(_ node: Node) -> Bool {
        switch kind {
        case .from: return store.fromId == node.id
        case .to:   return store.toId   == node.id
        }
    }

    private func select(_ node: Node) {
        switch kind {
        case .from: store.fromId = node.id
        case .to:   store.toId   = node.id
        }
        store.route = nil
        dismiss()
    }
}

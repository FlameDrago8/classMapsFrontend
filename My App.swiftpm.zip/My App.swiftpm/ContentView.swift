import SwiftUI
import MapKit

struct ContentView: View {
    @State private var store = NavigationStore()
    @State private var profile = ProfileStore()
    @State private var showFromPicker = false
    @State private var showToPicker = false
    @State private var showProfile = false
    @State private var mapPosition: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 30.56935, longitude: -97.85420),
            span: MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004)
        )
    )

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                mapLayer
                    .ignoresSafeArea()

                VStack {
                    HStack {
                        Spacer()
                        userButton
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 6)
                    Spacer()
                }

                bottomCard
                    .frame(maxWidth: .infinity)
                    .frame(height: store.route != nil ? geo.size.height * 0.4 : nil, alignment: .top)
                    .animation(.spring(response: 0.45, dampingFraction: 0.85), value: store.route)
            }
        }
        .task {
            await store.loadLocations()
            await profile.load()
            recenterMap()
        }
        .onChange(of: store.campus) { _, _ in recenterMap() }
        .onChange(of: store.route) { _, _ in recenterMap() }
        .sheet(isPresented: $showFromPicker) {
            NavigationStack {
                LocationPickerView(store: store, kind: .from)
            }
            .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showToPicker) {
            NavigationStack {
                LocationPickerView(store: store, kind: .to)
            }
            .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showProfile) {
            ProfileView(profile: profile, store: store)
        }
        .alert(
            "Routing error",
            isPresented: Binding(
                get: { store.errorMessage != nil },
                set: { if !$0 { store.clearError() } }
            ),
            presenting: store.errorMessage
        ) { _ in
            Button("OK", role: .cancel) { store.clearError() }
        } message: { msg in
            Text(msg)
        }
    }

    private var routeCoordinates: [CLLocationCoordinate2D] {
        guard let route = store.route else { return [] }
        return route.path
            .filter { $0.hasCoordinates }
            .map { CLLocationCoordinate2D(latitude: $0.lat, longitude: $0.lon) }
    }

    private var mapLayer: some View {
        let coords = routeCoordinates
        return Map(position: $mapPosition) {
            if coords.count >= 2 {
                MapPolyline(coordinates: coords)
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round))
            }
            if let first = coords.first {
                Annotation("Start", coordinate: first) {
                    ZStack {
                        Circle().fill(.white).frame(width: 22, height: 22)
                        Circle().fill(.green).frame(width: 14, height: 14)
                    }
                    .shadow(color: .black.opacity(0.25), radius: 3, y: 1)
                }
            }
            if let last = coords.last, coords.count > 1 {
                Annotation("End", coordinate: last) {
                    ZStack {
                        Circle().fill(.red).frame(width: 30, height: 30)
                        Image(systemName: "flag.checkered")
                            .foregroundStyle(.white)
                            .font(.caption.bold())
                    }
                    .shadow(color: .black.opacity(0.25), radius: 3, y: 1)
                }
            }
        }
        .mapStyle(.standard(elevation: .realistic))
    }

    private var bottomCard: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.secondary.opacity(0.4))
                .frame(width: 40, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 10)

            if let route = store.route {
                routeContent(route: route)
            } else {
                inputContent
            }
        }
        .frame(maxWidth: .infinity)
        .background(.regularMaterial)
        .clipShape(
            UnevenRoundedRectangle(
                topLeadingRadius: 22,
                bottomLeadingRadius: 0,
                bottomTrailingRadius: 0,
                topTrailingRadius: 22,
                style: .continuous
            )
        )
        .shadow(color: .black.opacity(0.15), radius: 14, y: -3)
    }

    private var inputContent: some View {
        VStack(spacing: 14) {
            Picker("Campus", selection: Binding(
                get: { store.campus },
                set: { value in Task { await store.selectCampus(value) } }
            )) {
                ForEach(Campus.allCases) { c in
                    Text(c.displayName).tag(c)
                }
            }
            .pickerStyle(.segmented)

            VStack(spacing: 0) {
                pickerRow(
                    title: "From",
                    icon: "circle.fill",
                    iconColor: .green,
                    node: store.fromNode
                ) { showFromPicker = true }

                Divider().padding(.leading, 50)

                pickerRow(
                    title: "To",
                    icon: "mappin.circle.fill",
                    iconColor: .red,
                    node: store.toNode
                ) { showToPicker = true }
            }
            .background(Color(uiColor: .secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

            HStack(spacing: 10) {
                Button {
                    store.swap()
                } label: {
                    Image(systemName: "arrow.up.arrow.down")
                        .font(.body.weight(.semibold))
                        .frame(width: 48)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.bordered)
                .disabled(!store.canSwap)

                Button {
                    Task { await store.computeRoute() }
                } label: {
                    HStack(spacing: 8) {
                        if store.isRouting {
                            ProgressView().controlSize(.small).tint(.white)
                        }
                        Text(store.isRouting ? "Routing…" : "Find Route")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .disabled(!store.canRoute || store.isRouting)
            }
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 18)
    }

    private func pickerRow(
        title: String,
        icon: String,
        iconColor: Color,
        node: Node?,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .foregroundStyle(iconColor)
                    .font(.title3)
                    .frame(width: 24)

                VStack(alignment: .leading, spacing: 1) {
                    Text(title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(node?.name ?? "Choose location")
                        .font(.body)
                        .foregroundStyle(node == nil ? .secondary : .primary)
                        .lineLimit(1)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.footnote)
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func routeContent(route: Route) -> some View {
        VStack(spacing: 0) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(route.etaLabel)
                        .font(.title2.bold())
                        .foregroundStyle(.primary)
                    Text("\(store.fromNode?.name ?? "Start") → \(store.toNode?.name ?? "End")")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    HStack(spacing: 14) {
                        Label("\(route.path.count) stops", systemImage: "mappin.and.ellipse")
                        if route.floorsTraversed > 1 {
                            Label("\(route.floorsTraversed) floors", systemImage: "building.2")
                        }
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                Spacer()

                HStack(spacing: 6) {
                    Button {
                        Task { await saveCurrentRoute() }
                    } label: {
                        Image(systemName: isCurrentRouteSaved ? "bookmark.fill" : "bookmark")
                            .font(.title3)
                            .foregroundStyle(Color.accentColor)
                    }

                    Button {
                        store.clearRoute()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 12)

            Divider()

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 14) {
                    ForEach(Array(route.steps.enumerated()), id: \.element.id) { idx, step in
                        StepRow(step: step, index: idx + 1, total: route.steps.count)
                    }
                }
                .padding(16)
            }
        }
    }

    private func recenterMap() {
        let coords = routeCoordinates
        let region: MKCoordinateRegion

        if coords.count >= 2 {
            let lats = coords.map(\.latitude)
            let lons = coords.map(\.longitude)
            let center = CLLocationCoordinate2D(
                latitude: (lats.min()! + lats.max()!) / 2,
                longitude: (lons.min()! + lons.max()!) / 2
            )
            let span = MKCoordinateSpan(
                latitudeDelta: max((lats.max()! - lats.min()!) * 1.8, 0.004),
                longitudeDelta: max((lons.max()! - lons.min()!) * 1.8, 0.004)
            )
            region = MKCoordinateRegion(center: center, span: span)
        } else {
            switch store.campus {
            case .rouse:
                region = MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: 30.56935, longitude: -97.85420),
                    span: MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004)
                )
            case .ut:
                region = MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: 30.28617, longitude: -97.73850),
                    span: MKCoordinateSpan(latitudeDelta: 0.012, longitudeDelta: 0.012)
                )
            }
        }

        withAnimation(.smooth(duration: 0.6)) {
            mapPosition = .region(region)
        }
    }

    private var userButton: some View {
        Button {
            showProfile = true
        } label: {
            ZStack {
                Circle().fill(.regularMaterial)
                Text(profile.initials)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.accentColor)
            }
            .frame(width: 44, height: 44)
            .shadow(color: .black.opacity(0.15), radius: 6, y: 2)
        }
    }

    private var currentRouteId: String? {
        guard let from = store.fromNode, let to = store.toNode else { return nil }
        return "\(store.campus.rawValue):\(from.id):\(to.id)"
    }

    private var isCurrentRouteSaved: Bool {
        guard let id = currentRouteId else { return false }
        return profile.isSaved(id)
    }

    private func saveCurrentRoute() async {
        guard let route = store.route,
              let from = store.fromNode,
              let to = store.toNode,
              let id = currentRouteId else { return }
        if profile.isSaved(id) {
            await profile.delete(id)
        } else {
            let saved = SavedRoute(
                id: id,
                campus: store.campus.rawValue,
                fromId: from.id,
                fromName: from.name,
                toId: to.id,
                toName: to.name,
                etaLabel: route.etaLabel
            )
            await profile.save(saved)
        }
    }
}

struct StepRow: View {
    let step: RouteStep
    let index: Int
    let total: Int

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            stepIcon
                .frame(width: 30, height: 30)

            VStack(alignment: .leading, spacing: 2) {
                Text(step.instruction)
                    .font(.callout)
                if let detail = step.detail {
                    Text(detail)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 0)
        }
    }

    @ViewBuilder
    private var stepIcon: some View {
        if index == 1 {
            ZStack {
                Circle().fill(.green)
                Image(systemName: "location.fill")
                    .foregroundStyle(.white)
                    .font(.caption2.bold())
            }
        } else if index == total {
            ZStack {
                Circle().fill(.red)
                Image(systemName: "flag.checkered")
                    .foregroundStyle(.white)
                    .font(.caption2.bold())
            }
        } else {
            ZStack {
                Circle().fill(Color.accentColor.opacity(0.18))
                Image(systemName: iconForKind(step.kind))
                    .foregroundStyle(Color.accentColor)
                    .font(.caption.bold())
            }
        }
    }

    private func iconForKind(_ kind: EdgeKind?) -> String {
        switch kind {
        case .stairsUp:    return "arrow.up"
        case .stairsDown:  return "arrow.down"
        case .elevator:    return "arrow.up.and.down"
        case .outdoor:     return "figure.walk"
        case .doorway:     return "door.left.hand.open"
        case .hallway:     return "arrow.right"
        case .none:        return "arrow.right"
        }
    }
}

import Foundation

enum GraphData {

    static let rouse: Graph = {
        let g = Graph()

        g.addNode(Node(id: "rouse-jct-1A", type: .junction, floor: 1, building: "Main", lat: 0, lon: 0, name: "Hallway A — North End"))
        g.addNode(Node(id: "rouse-jct-1B", type: .junction, floor: 1, building: "Main", lat: 0, lon: 0, name: "Hallway A — Middle"))
        g.addNode(Node(id: "rouse-jct-1C", type: .junction, floor: 1, building: "Main", lat: 0, lon: 0, name: "Hallway A — South End"))
        g.addNode(Node(id: "rouse-jct-1D", type: .junction, floor: 1, building: "Main", lat: 0, lon: 0, name: "Cross Hall — East"))
        g.addNode(Node(id: "rouse-jct-1E", type: .junction, floor: 1, building: "Main", lat: 0, lon: 0, name: "Cross Hall — West"))

        g.addNode(Node(id: "rouse-st-N-1", type: .stairs, floor: 1, building: "Main", lat: 0, lon: 0, name: "North Stairwell — Floor 1"))
        g.addNode(Node(id: "rouse-st-S-1", type: .stairs, floor: 1, building: "Main", lat: 0, lon: 0, name: "South Stairwell — Floor 1"))

        g.addNode(Node(id: "rouse-entrance",  type: .entrance, floor: 1, building: "Main", lat: 30.56935, lon: -97.85420, name: "Main Entrance"))
        g.addNode(Node(id: "rouse-cafeteria", type: .amenity,  floor: 1, building: "Main", lat: 0, lon: 0, name: "Cafeteria"))
        g.addNode(Node(id: "rouse-gym",       type: .amenity,  floor: 1, building: "Main", lat: 0, lon: 0, name: "Gymnasium"))
        g.addNode(Node(id: "rouse-library",   type: .amenity,  floor: 1, building: "Main", lat: 0, lon: 0, name: "Library"))
        g.addNode(Node(id: "rouse-office",    type: .amenity,  floor: 1, building: "Main", lat: 0, lon: 0, name: "Front Office"))

        for n in 101...106 {
            g.addNode(Node(id: "rouse-\(n)", type: .classroom, floor: 1, building: "Main", lat: 0, lon: 0, name: "Room \(n)"))
        }

        g.addNode(Node(id: "rouse-jct-2A", type: .junction, floor: 2, building: "Main", lat: 0, lon: 0, name: "Hallway A — North End (F2)"))
        g.addNode(Node(id: "rouse-jct-2B", type: .junction, floor: 2, building: "Main", lat: 0, lon: 0, name: "Hallway A — Middle (F2)"))
        g.addNode(Node(id: "rouse-jct-2C", type: .junction, floor: 2, building: "Main", lat: 0, lon: 0, name: "Hallway A — South End (F2)"))
        g.addNode(Node(id: "rouse-st-N-2", type: .stairs,   floor: 2, building: "Main", lat: 0, lon: 0, name: "North Stairwell — Floor 2"))
        g.addNode(Node(id: "rouse-st-S-2", type: .stairs,   floor: 2, building: "Main", lat: 0, lon: 0, name: "South Stairwell — Floor 2"))

        for n in 201...206 {
            g.addNode(Node(id: "rouse-\(n)", type: .classroom, floor: 2, building: "Main", lat: 0, lon: 0, name: "Room \(n)"))
        }

        g.addUndirectedEdge(from: "rouse-jct-1A", to: "rouse-jct-1B", seconds: 12, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-1B", to: "rouse-jct-1C", seconds: 12, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-1B", to: "rouse-jct-1D", seconds: 8,  kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-1B", to: "rouse-jct-1E", seconds: 8,  kind: .hallway)

        g.addUndirectedEdge(from: "rouse-jct-1A", to: "rouse-st-N-1", seconds: 4, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-1C", to: "rouse-st-S-1", seconds: 4, kind: .hallway)

        g.addUndirectedEdge(from: "rouse-entrance",  to: "rouse-jct-1B", seconds: 6,  kind: .doorway)
        g.addUndirectedEdge(from: "rouse-office",    to: "rouse-jct-1B", seconds: 5,  kind: .hallway)
        g.addUndirectedEdge(from: "rouse-cafeteria", to: "rouse-jct-1E", seconds: 10, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-gym",       to: "rouse-jct-1E", seconds: 18, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-library",   to: "rouse-jct-1D", seconds: 10, kind: .hallway)

        g.addUndirectedEdge(from: "rouse-101", to: "rouse-jct-1A", seconds: 6, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-102", to: "rouse-jct-1A", seconds: 6, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-103", to: "rouse-jct-1B", seconds: 5, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-104", to: "rouse-jct-1B", seconds: 5, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-105", to: "rouse-jct-1C", seconds: 6, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-106", to: "rouse-jct-1C", seconds: 6, kind: .hallway)

        g.addUndirectedEdge(from: "rouse-st-N-1", to: "rouse-st-N-2", seconds: 20, kind: .stairsUp)
        g.addUndirectedEdge(from: "rouse-st-S-1", to: "rouse-st-S-2", seconds: 20, kind: .stairsUp)

        g.addUndirectedEdge(from: "rouse-jct-2A", to: "rouse-jct-2B", seconds: 12, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-2B", to: "rouse-jct-2C", seconds: 12, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-2A", to: "rouse-st-N-2", seconds: 4,  kind: .hallway)
        g.addUndirectedEdge(from: "rouse-jct-2C", to: "rouse-st-S-2", seconds: 4,  kind: .hallway)

        g.addUndirectedEdge(from: "rouse-201", to: "rouse-jct-2A", seconds: 6, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-202", to: "rouse-jct-2A", seconds: 6, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-203", to: "rouse-jct-2B", seconds: 5, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-204", to: "rouse-jct-2B", seconds: 5, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-205", to: "rouse-jct-2C", seconds: 6, kind: .hallway)
        g.addUndirectedEdge(from: "rouse-206", to: "rouse-jct-2C", seconds: 6, kind: .hallway)

        return g
    }()

    static let ut: Graph = {
        let g = Graph()

        g.addNode(Node(id: "ut-gdc",     type: .building, floor: 0, building: "GDC", lat: 30.28621, lon: -97.73649, name: "GDC — Gates Dell Complex"))
        g.addNode(Node(id: "ut-pcl",     type: .building, floor: 0, building: "PCL", lat: 30.28269, lon: -97.73826, name: "PCL — Perry-Castañeda Library"))
        g.addNode(Node(id: "ut-rlp",     type: .building, floor: 0, building: "RLP", lat: 30.28473, lon: -97.73674, name: "RLP — Robert L. Patton Hall"))
        g.addNode(Node(id: "ut-gsb",     type: .building, floor: 0, building: "GSB", lat: 30.28547, lon: -97.73886, name: "GSB — Graduate School of Business"))
        g.addNode(Node(id: "ut-wel",     type: .building, floor: 0, building: "WEL", lat: 30.28683, lon: -97.73869, name: "WEL — Welch Hall"))
        g.addNode(Node(id: "ut-eer",     type: .building, floor: 0, building: "EER", lat: 30.28833, lon: -97.73572, name: "EER — Engineering Education & Research Center"))
        g.addNode(Node(id: "ut-tower",   type: .building, floor: 0, building: "MAI", lat: 30.28617, lon: -97.73935, name: "Main Building (UT Tower)"))
        g.addNode(Node(id: "ut-jcd",     type: .building, floor: 0, building: "JCD", lat: 30.28411, lon: -97.73383, name: "JCD — Jesse H. Jones Communication Center"))
        g.addNode(Node(id: "ut-cba",     type: .building, floor: 0, building: "CBA", lat: 30.28456, lon: -97.73881, name: "CBA — McCombs School of Business"))
        g.addNode(Node(id: "ut-union",   type: .building, floor: 0, building: "UNB", lat: 30.28686, lon: -97.74088, name: "Texas Union"))
        g.addNode(Node(id: "ut-gregory", type: .amenity,  floor: 0, building: "GRE", lat: 30.28371, lon: -97.73646, name: "Gregory Gymnasium"))

        g.addNode(Node(id: "ut-jct-speedway",   type: .junction, floor: 0, building: "—", lat: 30.28530, lon: -97.73730, name: "Speedway @ 24th St"))
        g.addNode(Node(id: "ut-jct-east-mall",  type: .junction, floor: 0, building: "—", lat: 30.28612, lon: -97.73796, name: "East Mall"))
        g.addNode(Node(id: "ut-jct-south-mall", type: .junction, floor: 0, building: "—", lat: 30.28471, lon: -97.73935, name: "South Mall"))

        g.addUndirectedEdge(from: "ut-pcl",            to: "ut-jct-speedway",   seconds: 90,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-jct-speedway",   to: "ut-rlp",            seconds: 60,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-rlp",            to: "ut-jct-east-mall",  seconds: 45,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-jct-east-mall",  to: "ut-gdc",            seconds: 110, kind: .outdoor)
        g.addUndirectedEdge(from: "ut-gdc",            to: "ut-eer",            seconds: 140, kind: .outdoor)

        g.addUndirectedEdge(from: "ut-jct-east-mall",  to: "ut-wel",            seconds: 75,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-jct-east-mall",  to: "ut-tower",          seconds: 80,  kind: .outdoor)

        g.addUndirectedEdge(from: "ut-tower",          to: "ut-jct-south-mall", seconds: 50,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-jct-south-mall", to: "ut-gsb",            seconds: 55,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-jct-south-mall", to: "ut-cba",            seconds: 65,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-gsb",            to: "ut-cba",            seconds: 40,  kind: .outdoor)

        g.addUndirectedEdge(from: "ut-jct-speedway",   to: "ut-gregory",        seconds: 110, kind: .outdoor)
        g.addUndirectedEdge(from: "ut-gregory",        to: "ut-jcd",            seconds: 140, kind: .outdoor)
        g.addUndirectedEdge(from: "ut-jcd",            to: "ut-pcl",            seconds: 120, kind: .outdoor)

        g.addUndirectedEdge(from: "ut-tower",          to: "ut-union",          seconds: 95,  kind: .outdoor)
        g.addUndirectedEdge(from: "ut-union",          to: "ut-wel",            seconds: 130, kind: .outdoor)

        return g
    }()

    static func graph(for campus: Campus) -> Graph {
        switch campus {
        case .rouse: return rouse
        case .ut:    return ut
        }
    }
}

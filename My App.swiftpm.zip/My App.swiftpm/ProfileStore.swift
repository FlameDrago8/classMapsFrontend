import Foundation
import Observation

@Observable
@MainActor
final class ProfileStore {

    private let cloud: CloudStore

    init(cloud: CloudStore = CloudStoreFactory.make()) {
        self.cloud = cloud
    }

    var displayName: String = "Student"
    var savedRoutes: [SavedRoute] = []
    var isWorking = false
    var errorMessage: String?

    var backendName: String { cloud.backendName }

    var initials: String {
        let parts = displayName.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }
        return letters.isEmpty ? "S" : String(letters).uppercased()
    }

    func load() async {
        isWorking = true
        defer { isWorking = false }
        do {
            displayName = try await cloud.loadDisplayName()
            savedRoutes = try await cloud.loadRoutes()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func updateDisplayName(_ name: String) async {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        displayName = trimmed.isEmpty ? "Student" : trimmed
        do {
            try await cloud.saveDisplayName(displayName)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func isSaved(_ id: String) -> Bool {
        savedRoutes.contains { $0.id == id }
    }

    func save(_ route: SavedRoute) async {
        do {
            try await cloud.saveRoute(route)
            savedRoutes = try await cloud.loadRoutes()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func delete(_ id: String) async {
        do {
            try await cloud.deleteRoute(id: id)
            savedRoutes.removeAll { $0.id == id }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func clearError() {
        errorMessage = nil
    }
}

import Foundation

struct SavedRoute: Codable, Identifiable, Hashable {
    let id: String
    let campus: String
    let fromId: String
    let fromName: String
    let toId: String
    let toName: String
    let etaLabel: String
}

protocol CloudStore: Sendable {
    var backendName: String { get }
    func loadDisplayName() async throws -> String
    func saveDisplayName(_ name: String) async throws
    func loadRoutes() async throws -> [SavedRoute]
    func saveRoute(_ route: SavedRoute) async throws
    func deleteRoute(id: String) async throws
}

struct LocalCloudStore: CloudStore {
    var backendName: String { "On-device" }

    private let defaults = UserDefaults.standard
    private let nameKey = "profile.displayName"
    private let routesKey = "profile.savedRoutes"

    func loadDisplayName() async throws -> String {
        defaults.string(forKey: nameKey) ?? "Student"
    }

    func saveDisplayName(_ name: String) async throws {
        defaults.set(name, forKey: nameKey)
    }

    func loadRoutes() async throws -> [SavedRoute] {
        guard let data = defaults.data(forKey: routesKey) else { return [] }
        return (try? JSONDecoder().decode([SavedRoute].self, from: data)) ?? []
    }

    func saveRoute(_ route: SavedRoute) async throws {
        var routes = try await loadRoutes()
        routes.removeAll { $0.id == route.id }
        routes.insert(route, at: 0)
        let data = try JSONEncoder().encode(routes)
        defaults.set(data, forKey: routesKey)
    }

    func deleteRoute(id: String) async throws {
        var routes = try await loadRoutes()
        routes.removeAll { $0.id == id }
        let data = try JSONEncoder().encode(routes)
        defaults.set(data, forKey: routesKey)
    }
}

enum CloudStoreFactory {
    static func make() -> CloudStore {
        #if canImport(FirebaseFirestore)
        return FirebaseCloudStore()
        #else
        return LocalCloudStore()
        #endif
    }
}

#if canImport(FirebaseFirestore)
import FirebaseFirestore
import FirebaseAuth

struct FirebaseCloudStore: CloudStore {
    var backendName: String { "Firebase" }

    private var db: Firestore { Firestore.firestore() }

    private var uid: String {
        Auth.auth().currentUser?.uid ?? "demo-user"
    }

    func loadDisplayName() async throws -> String {
        let doc = try await db.collection("users").document(uid).getDocument()
        return doc.data()?["displayName"] as? String ?? "Student"
    }

    func saveDisplayName(_ name: String) async throws {
        try await db.collection("users").document(uid).setData(["displayName": name], merge: true)
    }

    func loadRoutes() async throws -> [SavedRoute] {
        let snapshot = try await db.collection("users").document(uid).collection("savedRoutes").getDocuments()
        return snapshot.documents.compactMap { doc in
            let d = doc.data()
            guard let campus = d["campus"] as? String,
                  let fromId = d["fromId"] as? String,
                  let fromName = d["fromName"] as? String,
                  let toId = d["toId"] as? String,
                  let toName = d["toName"] as? String,
                  let etaLabel = d["etaLabel"] as? String else { return nil }
            return SavedRoute(id: doc.documentID, campus: campus, fromId: fromId, fromName: fromName, toId: toId, toName: toName, etaLabel: etaLabel)
        }
    }

    func saveRoute(_ route: SavedRoute) async throws {
        try await db.collection("users").document(uid).collection("savedRoutes").document(route.id).setData([
            "campus": route.campus,
            "fromId": route.fromId,
            "fromName": route.fromName,
            "toId": route.toId,
            "toName": route.toName,
            "etaLabel": route.etaLabel
        ])
    }

    func deleteRoute(id: String) async throws {
        try await db.collection("users").document(uid).collection("savedRoutes").document(id).delete()
    }
}
#endif

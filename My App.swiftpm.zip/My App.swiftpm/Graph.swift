import Foundation

struct MinHeap<Value> {
    private var storage: [(priority: Int, value: Value)] = []

    var isEmpty: Bool { storage.isEmpty }

    mutating func push(_ value: Value, priority: Int) {
        storage.append((priority, value))
        siftUp(storage.count - 1)
    }

    mutating func pop() -> (priority: Int, value: Value)? {
        guard !storage.isEmpty else { return nil }
        storage.swapAt(0, storage.count - 1)
        let removed = storage.removeLast()
        if !storage.isEmpty { siftDown(0) }
        return removed
    }

    private mutating func siftUp(_ index: Int) {
        var i = index
        while i > 0 {
            let parent = (i - 1) / 2
            if storage[i].priority < storage[parent].priority {
                storage.swapAt(i, parent)
                i = parent
            } else {
                break
            }
        }
    }

    private mutating func siftDown(_ index: Int) {
        var i = index
        let count = storage.count
        while true {
            let left = 2 * i + 1
            let right = 2 * i + 2
            var smallest = i
            if left < count && storage[left].priority < storage[smallest].priority {
                smallest = left
            }
            if right < count && storage[right].priority < storage[smallest].priority {
                smallest = right
            }
            if smallest == i { break }
            storage.swapAt(i, smallest)
            i = smallest
        }
    }
}

final class Graph {
    private(set) var nodes: [String: Node] = [:]
    private(set) var adjacency: [String: [AdjacentEdge]] = [:]

    func addNode(_ node: Node) {
        nodes[node.id] = node
        if adjacency[node.id] == nil { adjacency[node.id] = [] }
    }

    func addUndirectedEdge(from: String, to: String, seconds: Int, kind: EdgeKind) {
        adjacency[from, default: []].append(AdjacentEdge(to: to, seconds: seconds, kind: kind))
        adjacency[to, default: []].append(AdjacentEdge(to: from, seconds: seconds, kind: kind.reversed))
    }

    func shortestPath(from startId: String, to endId: String) -> (path: [Node], edges: [TraversedEdge], totalSeconds: Int)? {
        guard let start = nodes[startId], nodes[endId] != nil else { return nil }
        if startId == endId {
            return (path: [start], edges: [], totalSeconds: 0)
        }

        var dist: [String: Int] = [startId: 0]
        var prev: [String: (from: String, kind: EdgeKind, seconds: Int)] = [:]
        var visited: Set<String> = []
        var heap = MinHeap<String>()
        heap.push(startId, priority: 0)

        while let (priority, nodeId) = heap.pop() {
            if visited.contains(nodeId) { continue }
            visited.insert(nodeId)
            if nodeId == endId { break }

            for edge in adjacency[nodeId] ?? [] {
                if visited.contains(edge.to) { continue }
                let newDist = priority + edge.seconds
                if newDist < (dist[edge.to] ?? .max) {
                    dist[edge.to] = newDist
                    prev[edge.to] = (from: nodeId, kind: edge.kind, seconds: edge.seconds)
                    heap.push(edge.to, priority: newDist)
                }
            }
        }

        guard let total = dist[endId] else { return nil }

        var pathIds: [String] = []
        var edgesReversed: [TraversedEdge] = []
        var cursor = endId
        while cursor != startId {
            pathIds.append(cursor)
            guard let step = prev[cursor] else { return nil }
            edgesReversed.append(TraversedEdge(from: step.from, to: cursor, kind: step.kind, seconds: step.seconds))
            cursor = step.from
        }
        pathIds.append(startId)
        pathIds.reverse()
        edgesReversed.reverse()

        let path = pathIds.compactMap { nodes[$0] }
        return (path: path, edges: edgesReversed, totalSeconds: total)
    }
}

enum DirectionsBuilder {
    static func build(path: [Node], edges: [TraversedEdge]) -> [RouteStep] {
        guard !path.isEmpty else { return [] }

        var steps: [RouteStep] = []

        steps.append(RouteStep(
            instruction: "Start at \(path[0].name)",
            detail: path[0].subtitleInline,
            kind: nil
        ))

        if edges.isEmpty { return steps }

        var hallwaySecondsBuffer = 0
        var hallwayLastNode: Node? = nil

        for (idx, edge) in edges.enumerated() {
            let nextNode = path[idx + 1]

            switch edge.kind {
            case .hallway:
                hallwaySecondsBuffer += edge.seconds
                hallwayLastNode = nextNode

            default:
                if hallwaySecondsBuffer > 0, let target = hallwayLastNode {
                    steps.append(RouteStep(
                        instruction: "Walk down the hallway",
                        detail: "≈ \(hallwaySecondsBuffer) sec → \(target.name)",
                        kind: .hallway
                    ))
                    hallwaySecondsBuffer = 0
                    hallwayLastNode = nil
                }
                steps.append(stepFor(edge: edge, target: nextNode))
            }
        }

        if hallwaySecondsBuffer > 0, let target = hallwayLastNode {
            steps.append(RouteStep(
                instruction: "Walk down the hallway",
                detail: "≈ \(hallwaySecondsBuffer) sec → \(target.name)",
                kind: .hallway
            ))
        }

        steps.append(RouteStep(
            instruction: "Arrive at \(path.last!.name)",
            detail: path.last!.subtitleInline,
            kind: nil
        ))

        return steps
    }

    private static func stepFor(edge: TraversedEdge, target: Node) -> RouteStep {
        switch edge.kind {
        case .stairsUp:
            return RouteStep(instruction: "Take the stairs up to Floor \(target.floor)", detail: "≈ \(edge.seconds) sec", kind: .stairsUp)
        case .stairsDown:
            return RouteStep(instruction: "Take the stairs down to Floor \(target.floor)", detail: "≈ \(edge.seconds) sec", kind: .stairsDown)
        case .elevator:
            return RouteStep(instruction: "Take the elevator to Floor \(target.floor)", detail: "≈ \(edge.seconds) sec", kind: .elevator)
        case .outdoor:
            return RouteStep(instruction: "Walk outdoors to \(target.name)", detail: "≈ \(edge.seconds) sec", kind: .outdoor)
        case .doorway:
            return RouteStep(instruction: "Pass through \(target.name)", detail: "≈ \(edge.seconds) sec", kind: .doorway)
        case .hallway:
            return RouteStep(instruction: "Continue toward \(target.name)", detail: "≈ \(edge.seconds) sec", kind: .hallway)
        }
    }
}

private extension Node {
    var subtitleInline: String {
        switch type {
        case .building, .entrance, .amenity: return building
        default: return "Floor \(floor)"
        }
    }
}

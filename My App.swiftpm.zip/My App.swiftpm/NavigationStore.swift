import Foundation
import Observation

enum RoutingSource: String, CaseIterable, Identifiable {
    case onDevice
    case javaBackend

    var id: String { rawValue }

    var label: String {
        switch self {
        case .onDevice:    return "On-device (Swift)"
        case .javaBackend: return "Java backend"
        }
    }
}

@Observable
@MainActor
final class NavigationStore {

    private let localService: NavigationService = LocalNavigationService()
    private let remoteService: NavigationService

    init(remoteBaseURL: URL = URL(string: "http://localhost:8080")!) {
        self.remoteService = RemoteNavigationService(baseURL: remoteBaseURL)
    }

    var routingSource: RoutingSource = .onDevice

    private var service: NavigationService {
        routingSource == .onDevice ? localService : remoteService
    }

    var campus: Campus = .rouse

    var locations: [Node] = []
    var fromId: String?
    var toId: String?
    var route: Route?

    var isLoadingLocations = false
    var isRouting = false
    var errorMessage: String?

    var fromNode: Node? { locations.first(where: { $0.id == fromId }) }
    var toNode: Node?   { locations.first(where: { $0.id == toId }) }

    var canRoute: Bool {
        fromId != nil && toId != nil && fromId != toId
    }

    var canSwap: Bool {
        fromId != nil || toId != nil
    }

    func setRoutingSource(_ source: RoutingSource) async {
        guard source != routingSource else { return }
        routingSource = source
        route = nil
        await loadLocations()
    }

    func selectCampus(_ newCampus: Campus) async {
        guard newCampus != campus else { return }
        campus = newCampus
        fromId = nil
        toId = nil
        route = nil
        await loadLocations()
    }

    func loadLocations() async {
        isLoadingLocations = true
        defer { isLoadingLocations = false }
        do {
            self.locations = try await service.locations(campus: campus)
        } catch {
            self.errorMessage = error.localizedDescription
            self.locations = []
        }
    }

    func computeRoute() async {
        guard let from = fromId, let to = toId else { return }
        isRouting = true
        defer { isRouting = false }
        do {
            self.route = try await service.route(campus: campus, from: from, to: to)
        } catch {
            self.errorMessage = error.localizedDescription
            self.route = nil
        }
    }

    func applySavedRoute(campus savedCampus: Campus, fromId savedFrom: String, toId savedTo: String) async {
        if savedCampus != campus {
            campus = savedCampus
            await loadLocations()
        }
        fromId = savedFrom
        toId = savedTo
        await computeRoute()
    }

    func clearRoute() {
        route = nil
    }

    func swap() {
        let oldFrom = fromId
        fromId = toId
        toId = oldFrom
        route = nil
    }

    func clearError() {
        errorMessage = nil
    }
}

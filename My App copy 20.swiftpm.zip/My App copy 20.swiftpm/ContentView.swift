import SwiftUI
import MapKit

struct ContentView: View {
    @State private var travelTime: String = ""
    @State private var showingTravelPopup = false
    @State private var selectedFloor = 1
    @State private var currentRoute: MKRoute?
    
    @State private var userLocation: CLLocationCoordinate2D?
    func fetchTravelTime(lat: Double, lon: Double) {
        //REMEMBER TO ADD IN BACKEND HERE!!!
        guard let url = URL(string: "temp.com") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                if let decodedResponse = try? JSONDecoder().decode(TravelResponse.self, from: data) {
                    DispatchQueue.main.async {
                        self.travelTime = decodedResponse.time
                        self.showingTravelPopup = true
                    }
                }
            }
        }.resume()
    }
    
    struct TravelResponse: Codable {
        let time: String
    }

    @State private var position: MapCameraPosition = .region(MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 30.5694, longitude: -97.8543), span: MKCoordinateSpan(latitudeDelta:0.01, longitudeDelta: 0.01)
                                                                                   ))
    @State private var searchText = ""
    @State private var isSettingsPresented = false
        let rouse = Location(name: "Rouse High School", coordinate: CLLocationCoordinate2D(latitude: 30.5694, longitude: -97.8543)
        )
    var body: some View {
        NavigationStack {
            ZStack{
                Map(position: $position){
                    UserAnnotation()
                    if let route = self.currentRoute {
                        MapPolyline(route)
                            .stroke(.blue, lineWidth: 5)
                    }
                }
                .mapStyle(.standard(elevation:.realistic))
                .ignoresSafeArea()
                VStack{
                    HStack{
                        Button(action: {
                            isSettingsPresented = true
                        }) {
                            Image(systemName: "person.circle.fill")
                                .font(.largeTitle)
                                .foregroundColor(.blue)
                                .padding()
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                        }
                        Spacer()
                    }
                    Spacer()
                }
                .padding()
                VStack {
                    Spacer()
                    Picker("Floor", selection: $selectedFloor) {
                        Text("1st Floor").tag(1)
                        Text("2nd Floor").tag(2)
                    }
                    .pickerStyle(.segmented)
                    .background(.thinMaterial)
                    .padding()
                }

            }
            .safeAreaInset(edge: .bottom){
                TextField("Search for building...", text: $searchText)
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
                    .padding()
            }
            .sheet(isPresented: $isSettingsPresented){
                SettingsView()
            }
            .alert("Estimated Travel Time", isPresented: $showingTravelPopup) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("It will take approximately \(travelTime) to reach your destination.")
            }
        }
    }
}

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Profile")) {
                    Text("User Profile")
                    Text("Settings")
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                Button("Done"){
                    dismiss()
                }
            }
        }
    }
}
